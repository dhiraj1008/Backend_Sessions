const express = require("express");
const mong = require('mongoose');

const app = express();
app.use(express.json()); // middleware to parse JSON bodies

// Database connection
mong.connect("mongodb://127.0.0.1:27017/CollegeMSDB")
  .then(() => console.log("Connected to CollegeMSDB database successfully!"))
  .catch((err) => console.error("Database connection error:", err));

// Schemas-->rules on collection
const teacherSchema = new mong.Schema({
  name: { type: String, required: true },
  subject: { type: String, required: true },
  experience: { type: Number, default: 0 }
});

const studentSchema = new mong.Schema({
  name: { type: String, required: true },
  rollno: { type: Number, required: true },
  email: { type: String, default: "xyz@gmail.com" }
});

const courseSchema = new mong.Schema({
  title: { type: String, required: true },
  code: { type: Number, required: true },
  credits: { type: Number, default: 100 }
});

// Models
const Teacher = mong.model('Teacher', teacherSchema);
const Student = mong.model('Student', studentSchema);
const Course = mong.model('Course', courseSchema);


//Get Method implemention 

app.get('/api/students', async (req, res) => {
    try {
        const liststudents = await Student.find();
        res.status(200).json({
            message1:"list of students",
            data : liststudents
        });
    } catch (error) {
        res.status(404).json({ error: error.message });
    }
});

//teacher
app.get('/api/teachers', async (req, res) => {
    try {
        const listteachers = await Teacher.find();
        res.status(200).json({
            message1:"list of teachers",
            data : listteachers
        });
    } catch (error) {
        res.status(404).json({ error: error.message });
    }
});

//courses
app.get('/api/courses', async (req, res) => {
    try {
        const listcourses = await Course.find();
        res.status(200).json({
            message1:"list of courses",
            data : listcourses
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET a Specific Student by ID
app.get('/api/students/:id', async (req, res) => {
    try {
        const student = await Student.findById(req.params.id)
        //4 = > True
        if (!student) {
            return res.status(404).json({ message: "Student not found" });
        }
        
        res.status(200).json(student);
    } catch (error) {
        // Catches casting errors if the passed ID string is invalid
        res.status(500).json({ error: error.message });
    }
});
// GET a Specific Teacher by ID
app.get('/api/teachers/:id', async (req, res) => {
    try {
        const teacher = await Teacher.findById(req.params.id)
        //4 = > True
        if (!teacher) {
            return res.status(404).json({ message: "Teacher not found" });
        }
        
        res.status(200).json(teacher);
    } catch (error) {
        // Catches casting errors if the passed ID string is invalid
        res.status(500).json({ error: error.message });
    }
});
// GET a Specific courses by ID
app.get('/api/courses/:id', async (req, res) => {
    try {
        const course = await Course.findById(req.params.id)
        //4 = > True
        if (!course) {
            return res.status(404).json({ message: "Course not found" });
        }
        
        res.status(200).json(course);
    } catch (error) {
        // Catches casting errors if the passed ID string is invalid
        res.status(500).json({ error: error.message });
    }
});



// UPDATE a Student (PUT)
app.put('/api/students/:id', async (req, res) => {
    try {
        // { new: true } returns the modified document instead of the old one
        // { runValidators: true } ensures the update updates match your schema definitions
        const updatedStudent = await Student.findByIdAndUpdate(
            req.params.id, 
            req.body,
            {
        new: true,
        runValidators: true
    }
        )

        if (!updatedStudent) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.status(200).json({msg:"student updated",
                      data:updatedStudent
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// UPDATE a Teacher (PUT)
app.put('/api/teachers/:id', async (req, res) => {
    try {
        // { new: true } returns the modified document instead of the old one
        // { runValidators: true } ensures the update updates match your schema definitions
        const updatedTeacher = await Teacher.findByIdAndUpdate(
            req.params.id, 
            req.body,
            {
        new: true,
        runValidators: true
    }
        );

        if (!updatedTeacher) {
            return res.status(404).json({ message: "Teacher not found" });
        }

        res.status(200).json({msg:"teacher updated",
                      data:req.body
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// UPDATE a course (PUT)
app.put('/api/courses/:id', async (req, res) => {
    try {
        // { new: true } returns the modified document instead of the old one
        // { runValidators: true } ensures the update updates match your schema definitions
        const updatedCourse = await Course.findByIdAndUpdate(
            req.params.id, 
            req.body,
            {
        new: true,
        runValidators: true
    }
        );

        if (!updatedCourse) {
            return res.status(404).json({ message: "Course not found" });
        }

        res.status(200).json({msg:"course updated",
                      data:req.body
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 🚀 NEW: Route to Add and Save a Student
//POST
app.post("/api/students", async (req, res) => {
  try {
    // 1. Create a new student instance using data sent in the request body
    const newStudent = new Student({
      name: req.body.name,
      rollno: req.body.rollno,
      email: req.body.email // If empty, it defaults to "xyz@gmail.com"
    });

    // 2. Save the document to the MongoDB database
    const savedStudent = await newStudent.save();

    // 3. Send back a success response
    res.status(201).json({
      message: "Student added successfully!",
      data: savedStudent
    });
  } catch (error) {
    // Handle validation or connection errors
    res.status(400).json({ error: error.message });
  }
});
//Teachers
app.post("/api/teachers", async (req, res) => {
  try {
    // 1. Create a new student instance using data sent in the request body
    const newTeacher = new Teacher({
      name: req.body.name,
      subject: req.body.subject,
      experience: req.body.experience // If empty, it defaults to "xyz@gmail.com"
    });

    // 2. Save the document to the MongoDB database
    const savedTeacher = await newTeacher.save();

    // 3. Send back a success response
    res.status(201).json({
      message: "Teacher added successfully!",
      data: savedTeacher
    });
  } catch (error) {
    // Handle validation or connection errors
    res.status(400).json({ error: error.message });
  }
});
//Courses
app.post("/api/courses", async (req, res) => {
  try {
    // 1. Create a new student instance using data sent in the request body
    const newCourse = new Course({
      title: req.body.title,
      code: req.body.code,
      credits: req.body.credits // If empty, it defaults to "xyz@gmail.com"
    });

    // 2. Save the document to the MongoDB database
    const savedCourse = await newCourse.save();

    // 3. Send back a success response
    res.status(201).json({
      message: "Course added successfully!",
      data: savedCourse
    });
  } catch (error) {
    // Handle validation or connection errors
    res.status(400).json({ error: error.message });
  }
});
//DELETE
app.delete('/api/students/:id', async (req, res) => {
    try {
        const deletedStudent = await Student.findByIdAndDelete(req.params.id);

        if (!deletedStudent) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.status(200).json({ 
            message: "Student record deleted successfully", 
            deletedStudent 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
//Teacher
app.delete('/api/teachers/:id', async (req, res) => {
    try {
        const deletedTeacher = await Teacher.findByIdAndDelete(req.params.id);

        if (!deletedTeacher) {
            return res.status(404).json({ message: "Teacher not found" });
        }

        res.status(200).json({ 
            message: "Teacher record deleted successfully", 
            deletedTeacher
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
//COURSE
app.delete('/api/courses/:id', async (req, res) => {
    try {
        const deletedCourse = await Course.findByIdAndDelete(req.params.id);

        if (!deletedCourse) {
            return res.status(404).json({ message: "Course not found" });
        }

        res.status(200).json({ 
            message: "Course record deleted successfully", 
            deletedCourse
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start server
app.listen(3000, () => {
  console.log("Server running on port 3000");
});