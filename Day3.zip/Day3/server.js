//Basic Get route
const express = require('express');
const app = express();
//home page
app.get('/', (req, res) => {
res.send('Hello from Express!');
});
// about
app.get('/about', (req, res) => {
res.send('About Page!');
});
//contact
app.get('/contact', (req, res) => {
res.send('contact page!');
});
//login
app.get('/login', (req, res) => {
res.send('Login Page');
});
app.listen(8080,() => {
console.log('Server running on port 8080');
}